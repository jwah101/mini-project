let data =[
{
  id: 0,
  name : '강동구축구연합회',
  address : '서울 송파구 방이동 88-13',
  price : "10,000"
},
{
  id: 1,
  name : '노량진축구장',
  address : '서울 동작구 노들로 688',
  price : "10,000"
},
{
  id: 2,
  name : '서울어린이대공원축구장',
  address : '서울 광진구 능동로 216',
  price : "10,000"
},
{
  id: 3,
  name : '성내유수지축구장',
  address : '서울 송파구 방이동 88-13',
  price : "10,000"
},
{
  id: 4,
  name : '송파여성축구장',
  address : '서울특별시 송파구 올림픽로 474',
  price : "10,000"
},
{
  id: 5,
  name : '용마폭포공원축구장',
  address : '서울특별시 중랑구 용마산로 250-12',
  price : "10,000"
},
{
  id: 6,
  name : '중랑물재생센터축구장',
  address : '서울 성동구 용답동 245',
  price : "10,000"
},
{
  id: 7,
  name : '창골축구장',
  address : '서울 도봉구 해등로3길 48-11 창골축구장',
  price : "10,000"
},
{
  id: 8,
  name : '탄천종합운동장',
  address : '경기도 성남시 분당구 탄천로 215',
  price : "10,000"
},
]

export default data;